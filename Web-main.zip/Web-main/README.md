Nhóm 01

Các bước để chạy web: 

Bước 1: git clone : https://github.com/VAnhNguyen2401/Web.git

Bước 2: chạy bằng VSCode

Bước 3: thay tên file .env.example thành .env

Bước 4: restore file QuanLiChungCuSkyBACKUP.bak

Bước 5: bật terminal chạy lệnh 
      npm install
      npm start

Bước 6: truy cập link: http://localhost:8080/
